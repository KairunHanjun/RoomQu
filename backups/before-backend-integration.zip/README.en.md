# RoomQu — portfolio demo

Property operations application with four roles: Host, Front Office, House Keeping, and Technician. The default demo uses **a local SQLite file and fictional data**. PostgreSQL, Cloudinary, and external accounts are not required. Indonesian instructions: [README.md](README.md).

## Run locally

Requires Node.js 24 or newer. In the RoomQu folder:

```powershell
npm install
.\start-demo.ps1
```

Open http://127.0.0.1:1231. If dependencies are installed, run only the launcher. Alternative: `npm run dev:demo`. The launcher explicitly selects demo mode. Custom port: `.\start-demo.ps1 -Port 1232`.

| Role | Username | Password |
| --- | --- | --- |
| Host | host.demo | DemoRoom123! |
| Front Office | front.demo | DemoRoom123! |
| House Keeping | clean.demo | DemoRoom123! |
| Technician | tech.demo | DemoRoom123! |

Role buttons fill in the demo credentials. Urban Residence and all accounts are fictional. The current application interface is in Indonesian; the portfolio write-ups are provided separately in both languages.

## Demonstrated workflows

Host manages units, staff, booking agents and commission rates; reviews cleaning reports; views bookings and attendance; and exports Excel workbooks. Front Office checks guests in and out with server-calculated prices. House Keeping submits room and bathroom cleaning evidence. Technicians resolve maintenance issues. Staff can record their own attendance once per day.

Normal lifecycle: **Ready → Occupied → Awaiting cleaning → House Keeping report → Host approval → Ready**. Severe issues close vacant units. Resolving maintenance returns a closed unit to cleaning inspection. Occupied units remain occupied until checkout.

## Local data and reset

The application creates `.demo/roomqu.sqlite` automatically. Uploaded images are stored locally as SQLite BLOBs (PNG/JPEG/WebP, up to 2 MB each). Without uploads, explicitly labeled local illustrations are used; they are not photographs of a real property. Fonts are local. Attendance days use Bangkok time (UTC+7).

Data persists across restarts. To reset all dummy data, stop the server and run:

```powershell
npm run demo:reset
.\start-demo.ps1
```

Reset clears demo sessions and uploaded images as well. `ROOMQU_DEMO_DIR` optionally selects a different database directory; use the same value when running and resetting.

## Verification

```powershell
npm run test:demo
npm run check
npm run build
```

The backend tests cover unit transitions, validation, role/property isolation, sessions, local image storage, Excel output, and persistence. `npm run test:http` requires a running server and fresh seed data; it adds one dummy attendance record. Reset before repeating. Evidence: `../portfolio-materials/RoomQu-verification.md`; screenshots: `../portfolio-materials/screenshots/RoomQu`.

## Scope

Demo routes live under `/demo`. All mutations are validated on the server. Sessions use HttpOnly cookies, mutating requests require the application origin, and access is limited by role and property. Legacy APIs and the old PWA cache are disabled in demo mode.

Previous PostgreSQL/Cloudinary source is retained for reference. `ROOMQU_MODE=live` selects that legacy code; it has not been verified for production. Local builds use adapter-auto; public hosting and a persistent Node server adapter have not been configured. No real payment, identity, or property operations are performed.

Dependencies in this session were installed with pnpm using package.json ranges; an exact npm ci reproduction has not been tested. Prettier is pinned to 3.6.2 for Svelte plugin compatibility. The owner reports 100% individual contribution to the original project; demo preparation and portfolio cleanup were assisted by Codex.
