import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema';
import { env } from '$env/dynamic/private';

// The legacy client connects lazily. Demo requests never call this database.


const client = postgres(env.DATABASE_URL_DEV || 'postgres://unused:unused@127.0.0.1:5432/roomqu_legacy');

export const db = drizzle(client, { schema });
