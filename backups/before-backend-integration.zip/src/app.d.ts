// See https://svelte.dev/docs/kit/types#app.d.ts
// for information about these interfaces
declare global {
	namespace App {
		interface Locals {
            demoUser: import('$lib/server/demo/store').DemoUser | null;
			user: import('$lib/server/auth').SessionValidationResult['user'];
			session: import('$lib/server/auth').SessionValidationResult['session'];
		}
	} // interface Error {}
	// interface Locals {
            demoUser: import('$lib/server/demo/store').DemoUser | null;}
} // interface PageData {}
// interface PageState {}

// interface Platform {}
export {};
