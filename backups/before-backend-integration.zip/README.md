# RoomQu — demo portofolio

Aplikasi operasional properti dengan empat peran: Host, Front Office, House Keeping, dan Teknisi. Mode default memakai **SQLite lokal dengan data fiktif**, sehingga dapat dicoba tanpa PostgreSQL, Cloudinary, atau akun eksternal. Dokumentasi Inggris: [README.en.md](README.en.md).

## Menjalankan

Memerlukan Node.js 24 atau lebih baru. Dari folder RoomQu:

```powershell
npm install
.\start-demo.ps1
```

Buka http://127.0.0.1:1231. Bila dependensi sudah tersedia, cukup jalankan launcher. Alternatif: `npm run dev:demo`. Launcher selalu memilih mode demo. Untuk port lain: `.\start-demo.ps1 -Port 1232`.

| Peran | Username | Kata sandi |
| --- | --- | --- |
| Host | host.demo | DemoRoom123! |
| Front Office | front.demo | DemoRoom123! |
| House Keeping | clean.demo | DemoRoom123! |
| Teknisi | tech.demo | DemoRoom123! |

Klik tombol peran pada halaman login untuk mengisi akun contoh. Semua akun dan properti Urban Residence bersifat fiktif.

## Alur yang dapat dicoba

- Host: ringkasan okupansi, tambah unit, kelola staf, tambah agen dan komisi, tinjau kebersihan, riwayat tamu, absensi tim, dan ekspor Excel.
- Front Office: check-in pada unit siap, perhitungan tarif dan komisi oleh server, check-out, laporan kendala, dan absensi sendiri.
- House Keeping: laporan kebersihan ruangan/kamar mandi untuk unit yang menunggu dibersihkan, dokumentasi, laporan kendala, dan absensi.
- Teknisi: daftar masalah dan penandaan selesai, laporan kendala baru, status unit, dan absensi.

Alur normal: **Siap → Terisi → Menunggu bersih → laporan House Keeping → persetujuan Host → Siap**. Masalah berat menutup unit kosong; selesai diperbaiki tetap memerlukan pemeriksaan kebersihan. Unit berisi tamu tetap terisi sampai check-out.

## Data lokal

File `.demo/roomqu.sqlite` dibuat otomatis saat pertama diakses. Gambar unggahan tersimpan sebagai BLOB pada SQLite; tidak dikirim ke layanan luar. PNG/JPEG/WebP maksimum 2 MB. Tanpa unggahan, aplikasi memakai ilustrasi lokal berlabel demo, bukan foto properti nyata. Font juga lokal. Hari absensi memakai UTC+7 (Bangkok).

Data **tetap ada setelah restart**. Untuk mengembalikan semua data dummy, hentikan server lalu:

```powershell
npm run demo:reset
.\start-demo.ps1
```

Reset juga menghapus sesi dan unggahan demo. `ROOMQU_DEMO_DIR` dapat menentukan direktori database lain; gunakan nilai yang sama untuk server dan reset. Jangan arahkan ke data penting.

## Pemeriksaan

```powershell
npm run test:demo
npm run check
npm run build
```

Tes backend mencakup state unit, validasi, peran, pemisahan properti, sesi, gambar lokal, file Excel, dan persistensi. `npm run test:http` memerlukan server aktif serta data awal; tes ini menambahkan satu absensi dummy. Reset sebelum menjalankannya lagi. Hasil verifikasi dan galeri tersedia di `../portfolio-materials/RoomQu-verification.md` serta `../portfolio-materials/screenshots/RoomQu`.

## Batas demo dan kode lama

Antarmuka demo ada di `/demo`, penyimpanan di `src/lib/server/demo`, dan aksi divalidasi di server. Cookie sesi HttpOnly, mutasi hanya dari origin aplikasi, akses dibatasi berdasarkan peran dan properti. Endpoint API lama ditutup pada mode demo, dan PWA lama dinonaktifkan agar tidak menyimpan halaman sesi.

Source integrasi PostgreSQL/Cloudinary sebelumnya dipertahankan untuk referensi. `ROOMQU_MODE=live` memilih jalur lama; jalur itu **belum diverifikasi untuk produksi**. Build lokal berhasil memakai adapter-auto, tetapi target deployment dan adapter server persisten belum dipilih. Demo ini tidak memproses pembayaran, data identitas nyata, atau operasi properti sungguhan.

Instalasi sesi ini memakai pnpm mengikuti rentang versi package.json; tidak diklaim sebagai pengujian npm ci dari lockfile. Prettier 3.6.2 dipatok untuk kompatibilitas plugin Svelte. Kontribusi pemilik proyek: 100%, berdasarkan konfirmasi pemilik; persiapan demo dan perapian portofolio dibantu Codex.
